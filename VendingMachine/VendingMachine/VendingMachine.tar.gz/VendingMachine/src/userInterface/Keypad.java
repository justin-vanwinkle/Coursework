/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package userInterface;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author justin
 */

public class Keypad extends javax.swing.JPanel 
{
    private JButton buttonA;
    private JButton buttonB;
    private JButton buttonC;
    private JButton buttonD;
    private JButton button0;
    private JButton button1;
    private JButton button2;
    private JButton button3;
    private JButton button4;
    private JButton button5;
    private JButton button6;
    private JButton button7;
    private JButton button8;
    private JButton button9;
    private JButton buttonMoney;
    private JButton buttonDot;
    private JLabel moneyEntered;
    
    //Pre-Conditions :  None
    //Post-Conditions:  Calls initComponents method
    //Additional Info:  This provides external class visibility and prevents
    //               :  the change of any data in the private method it calls.
    public Keypad()
    {
        initComponents();
        
    }
    
    //Pre-Conditions :  None
    //Post-Conditions:  Handles the initialization of all components to be added
    //               :  to the Keypad JPanel.
    private void initComponents()
    {
        // Instantiate GridBagLayout for keypad which is an extension of JPanel
        this.setLayout(new GridBagLayout());
        // Set a border around the JPanel
        this.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        
        // Instantiate all buttons with text
        button0 = new JButton("0");
        button1 = new JButton("1");
        button2 = new JButton("2");
        button3 = new JButton("3");
        button4 = new JButton("4");
        button5 = new JButton("5");
        button6 = new JButton("6");
        button7 = new JButton("7");
        button8 = new JButton("8");
        button9 = new JButton("9");
        buttonA = new JButton("A");
        buttonB = new JButton("B");
        buttonC = new JButton("C");
        buttonD = new JButton("D");
        buttonDot = new JButton(".");
        buttonMoney = new JButton("Enter Money");
        buttonMoney.setPreferredSize(new Dimension(150,25));
        
        //Registering ActionListeners
        button0.addActionListener(new KeyAction());
        button1.addActionListener(new KeyAction());
        button2.addActionListener(new KeyAction());
        button3.addActionListener(new KeyAction());
        button4.addActionListener(new KeyAction());
        button5.addActionListener(new KeyAction());
        button6.addActionListener(new KeyAction());
        button7.addActionListener(new KeyAction());
        button8.addActionListener(new KeyAction());
        button9.addActionListener(new KeyAction());
        buttonA.addActionListener(new KeyAction());
        buttonB.addActionListener(new KeyAction());
        buttonC.addActionListener(new KeyAction());
        buttonD.addActionListener(new KeyAction());
        buttonDot.addActionListener(new KeyAction());
        buttonMoney.addActionListener(new MoneyAction());

        // Instantiate JLabel
        moneyEntered = new JLabel("$0.00");
        
        // Call addComponent to set constraints and add component to panel
        addComponent(2, 6, 1, 1, 0.1, 0.1, this, button0);
        addComponent(1, 3, 1, 1, 0.1, 0.1, this, button1);
        addComponent(2, 3, 1, 1, 0.1, 0.1, this, button2);
        addComponent(3, 3, 1, 1, 0.1, 0.1, this, button3);
        addComponent(1, 4, 1, 1, 0.1, 0.1, this, button4);
        addComponent(2, 4, 1, 1, 0.1, 0.1, this, button5);
        addComponent(3, 4, 1, 1, 0.1, 0.1, this, button6);
        addComponent(1, 5, 1, 1, 0.1, 0.1, this, button7);
        addComponent(2, 5, 1, 1, 0.1, 0.1, this, button8);
        addComponent(3, 5, 1, 1, 0.1, 0.1, this, button9);
        addComponent(0, 3, 1, 1, 0.1, 0.1, this, buttonA);
        addComponent(0, 4, 1, 1, 0.1, 0.1, this, buttonB);
        addComponent(0, 5, 1, 1, 0.1, 0.1, this, buttonC);
        addComponent(0, 6, 1, 1, 0.1, 0.1, this, buttonD);
        addComponent(3, 6, 1, 1, 0.1, 0.1, this, buttonDot);
        addComponent(0, 7, 4, 1, 0.1, 1.0, this, buttonMoney);
        addComponent(0, 0, 4, 2, 0.1, 0.7, this, moneyEntered);

    }
    
    //Pre-Condition :   x, y, gw, and gh are all of type int.
    //              :   wx and wy are of type double.
    //              :   aContainer is of type Container
    //              :   aComponent is of type Component
    //Post-Condition:   sets GridBagConstraints and adds specified component to 
    //              :   specified container.
    private void addComponent(int x, int y, int gw, int gh, double wx, double wy, Container aContainer, 
        Component aComponent)
    {
        GridBagLayout gridBagLayout = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = x;
        c.gridy = y;
        c.gridwidth = gw;
        c.gridheight = gh;
        c.weightx = wx;
        c.weighty = wy;
        gridBagLayout.setConstraints(aComponent, c);
        aContainer.add(aComponent, c);
    }
    
    // Registering event handler to Buttons
    private class KeyAction implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) 
        {
            String option = "";
            switch(e.getActionCommand())
            {
                case "0":
                    option = e.getActionCommand();
                    break;
                case "1":
                    option = e.getActionCommand();
                    break;
                case "2":
                    option = e.getActionCommand();
                    break;
                case "3":
                    option = e.getActionCommand();
                    break;
                case "4":
                    option = e.getActionCommand();
                    break;
                case "5":
                    option = e.getActionCommand();
                    break;
                case "6":
                    option = e.getActionCommand();
                    break;
                case "7":
                    option = e.getActionCommand();
                    break;
                case "8":
                    option = e.getActionCommand();
                    break;
                case "9":
                    option = e.getActionCommand();
                    break;
                case "A":
                    option = e.getActionCommand();
                    break;
                case "B":
                    option = e.getActionCommand();
                    break;                
                case "C":
                    option = e.getActionCommand();
                    break;
                case "D":
                    option = e.getActionCommand();
                    break;   
                case ".":
                    option = e.getActionCommand();
                    break;  
            }
            System.out.println("You pressed: [" + option + "]");
        }
    }
    
    // Registering event handler to money input
    private class MoneyAction implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            String option = "";
            
            switch(e.getActionCommand())
            {
                case "Enter Money":
                    option = e.getActionCommand();
                    buttonMoney.setText("Stop Money");
                    break;
                case "Stop Money":
                    option = e.getActionCommand();
                    buttonMoney.setText("Enter Money");
                    break;
            }
            
            System.out.println("You pressed: [" + option + "]");
        }
    }
}

