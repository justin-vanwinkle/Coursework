/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package core;

/**
 *
 * @author justin
 */
public class BillValidator {
    //TODO method for validating individual bills
    //TODO method for handling the rejection of bills
    
}
