/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package core;

/**
 *
 * @author justin
 */
public class Sensors {
    //TODO method for detecting an input bill (this would start the motors)
    //TODO method for scanning an image of a bill
    //TODO method for detecting the diameter of a coin
    //TODO method for product delivery detection (successful transaction)
}
