/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package core;

/**
 *
 * @author justin
 */
public class ProductManager {
    //TODO method for stocking machine
    //TODO method for tracking product levels
    //TODO method for handling product prices
}
