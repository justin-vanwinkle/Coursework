/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package core;

/**
 *
 * @author justin
 */
public class Enumerations {
    
    public enum VendingState {READY, MONEY, PRODUCT, DISPENSED, COMPLETE};
    public enum BillValid {TRUE, FALSE};
    public enum CoinValid {TRUE, FALSE};
    public enum Dispensed {TRUE, FALSE};   
      
}